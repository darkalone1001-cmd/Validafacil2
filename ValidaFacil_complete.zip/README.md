ValidaFácil - Mercantil Novinho
Projeto gerado para facilitar controle de validade de produtos.

Instruções resumidas:
1. Crie um repositório no GitHub.
2. Faça upload deste ZIP (Upload files).
3. Vá em Actions -> Android - Build APK -> Run workflow.
4. Baixe o artifact app-release quando concluir.

Cores do app: amarelo (#FFD600) e vermelho (#D32F2F)
