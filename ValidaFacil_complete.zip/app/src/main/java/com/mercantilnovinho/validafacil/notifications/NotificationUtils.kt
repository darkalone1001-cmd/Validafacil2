package com.mercantilnovinho.validafacil.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import com.mercantilnovinho.validafacil.R

object NotificationUtils {
    const val CHANNEL_ID = "validafacil_channel"
    const val CHANNEL_NAME = "ValidaFácil Alerts"

    fun createChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Alertas de produtos próximos da validade"
            nm.createNotificationChannel(channel)
        }
    }

    fun build(context: Context, title:String, text:String) =
        NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setAutoCancel(true)
            .build()
}
