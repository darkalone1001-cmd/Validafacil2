package com.mercantilnovinho.validafacil.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.mercantilnovinho.validafacil.data.AppDatabase
import com.mercantilnovinho.validafacil.notifications.Scheduler

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null) return
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_REBOOT) {
            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getInstance(context)
                val list = db.productDao().getAllList()
                list.forEach { Scheduler.scheduleNotifications(context, it) }
            }
        }
    }
}
