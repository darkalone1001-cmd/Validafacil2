package com.mercantilnovinho.validafacil.ui

import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mercantilnovinho.validafacil.data.Product
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun ProductListScreen() {
    // Placeholder static list for APK demo (without Room wiring at runtime)
    val fmt = DateTimeFormatter.ISO_LOCAL_DATE
    val sample = listOf(
        Product(id="1", category="Laticínios", name="Leite", brand="Mercantil Novinho", flavor=null, weight="1L", quantity=8, expiryDateIso=LocalDate.now().plusDays(6).format(fmt)),
        Product(id="2", category="Mercearia", name="Arroz", brand="Grão Bom", flavor="Integral", weight="1kg", quantity=4, expiryDateIso=LocalDate.now().plusDays(15).format(fmt))
    )

    Scaffold(
        topBar = { TopAppBar(title = { Text("ValidaFácil - Mercantil Novinho") }, backgroundColor = MaterialTheme.colors.primary) },
        floatingActionButton = {
            FloatingActionButton(onClick = { /* open add screen */ }, backgroundColor = MaterialTheme.colors.secondary) {
                Text("+")
            }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(16.dp)) {
            items(sample) { p ->
                ProductRow(p, onDelete = {})
            }
        }
    }
}

@Composable
fun ProductRow(p: Product, onDelete: () -> Unit) {
    val fmt = DateTimeFormatter.ISO_LOCAL_DATE
    val expiry = LocalDate.parse(p.expiryDateIso, fmt)
    val daysLeft = java.time.Duration.between(LocalDate.now().atStartOfDay(), expiry.atStartOfDay()).toDays()
    val color = when {
        daysLeft <= 0 -> MaterialTheme.colors.error
        daysLeft <= 3 -> MaterialTheme.colors.secondary
        daysLeft <= 7 -> MaterialTheme.colors.primaryVariant
        else -> MaterialTheme.colors.onSurface
    }

    Card(modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 6.dp)) {
        Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("${p.name} — ${p.brand}")
                Text("${p.category} • ${p.flavor ?: ""} • ${p.weight ?: ""}")
                Text("Validade: ${p.expiryDateIso}  •  Qtd: ${p.quantity}")
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("${daysLeft} dias", color = color)
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = onDelete) { Text("Remover") }
            }
        }
    }
}
