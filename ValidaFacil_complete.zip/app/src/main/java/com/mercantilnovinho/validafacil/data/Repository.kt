package com.mercantilnovinho.validafacil.data

import kotlinx.coroutines.flow.Flow

class Repository(private val dao: ProductDao) {
    fun getAll() : Flow<List<Product>> = dao.getAll()
    suspend fun insert(p: Product) = dao.insert(p)
    suspend fun delete(p: Product) = dao.delete(p)
    suspend fun getById(id: String) = dao.getById(id)
    suspend fun getAllList() = dao.getAllList()
}
